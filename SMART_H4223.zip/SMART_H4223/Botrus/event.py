class Event:

    def __init__(self, name, data):

        self.name = name
        self.data = data